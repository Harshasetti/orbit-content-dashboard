import type { ContentItem } from './types';
export const mockNews: ContentItem[] = [
 {id:'ai-everyday',type:'Technology',kind:'NEWS',emoji:'🤖',title:'The quiet revolution happening in everyday AI',desc:'A practical look at how helpful assistants and creative tools are changing the way people work.',source:'The Signal',time:'12 min ago',color:'tech'},
 {id:'privacy-basics',type:'Technology',kind:'EXPLAINER',emoji:'🔐',title:'Digital privacy basics worth a second look',desc:'A friendly guide to permissions, passkeys, and settings that put you back in control.',source:'Bytewise',time:'2 hrs ago',color:'tech'},
 {id:'money-habits',type:'Finance',kind:'INSIGHT',emoji:'📈',title:'A calmer approach to long-term money habits',desc:'Why consistency, clear goals, and understanding risk can matter more than watching every market move.',source:'The Ledger',time:'42 min ago',color:'finance'},
 {id:'slow-living',type:'Culture',kind:'CULTURE',emoji:'🌿',title:'The case for making room for slow living',desc:'A design movement rethinking routines, spaces, and what a satisfying day can look like.',source:'Good Things',time:'1 hr ago',color:'culture'},
 {id:'indie-films',type:'Entertainment',kind:'WATCHLIST',emoji:'🎬',title:'Five independent films for your weekend list',desc:'Small stories, bold directors, and films that stay with you long after the credits.',source:'Screen Scene',time:'28 min ago',color:'movie'},
 {id:'subscription-audit',type:'Finance',kind:'GUIDE',emoji:'💡',title:'The small subscription audit that adds up',desc:'A simple framework for deciding what to keep, pause, or cancel.',source:'The Ledger',time:'3 hrs ago',color:'finance'}
];
export const mockSocial: ContentItem[] = [
 {id:'community-learning',type:'Social',kind:'COMMUNITY',emoji:'💬',title:'What are you learning just for fun?',desc:'A community thread full of side quests, unexpected hobbies, and tiny skills worth picking up.',source:'Orbit Community',time:'1 hr ago',color:'social'},
 {id:'weekly-rituals',type:'Social',kind:'COMMUNITY',emoji:'☕',title:'The little rituals that help reset your week',desc:'Thoughtful routines from people making space for what matters.',source:'Orbit Community',time:'Yesterday',color:'social'}
];
