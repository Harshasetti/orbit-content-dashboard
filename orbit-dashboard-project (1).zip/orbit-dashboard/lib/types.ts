export type ContentCategory = 'Technology' | 'Culture' | 'Finance' | 'Entertainment' | 'Social';
export type ContentItem = { id: string; type: ContentCategory; kind: string; emoji: string; title: string; desc: string; source: string; time: string; color: string; url?: string };
