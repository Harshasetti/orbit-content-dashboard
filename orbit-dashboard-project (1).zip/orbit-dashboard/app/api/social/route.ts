import { NextResponse } from 'next/server';
import { mockSocial } from '@/lib/mock-data';
export async function GET(){return NextResponse.json({items:mockSocial,source:'mock'});}
