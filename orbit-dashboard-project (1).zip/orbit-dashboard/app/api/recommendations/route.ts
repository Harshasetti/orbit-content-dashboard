import { NextResponse } from 'next/server';
import { mockNews } from '@/lib/mock-data';
export async function GET() {
 const key=process.env.TMDB_API_KEY;
 if(!key) return NextResponse.json({items:mockNews.filter(x=>x.type==='Entertainment'),source:'mock',notice:'Set TMDB_API_KEY to enable live movie recommendations.'});
 try { const res=await fetch('https://api.themoviedb.org/3/trending/movie/week',{headers:{Authorization:`Bearer ${key}`},next:{revalidate:3600}}); if(!res.ok) throw new Error('TMDB request failed'); const data=await res.json(); const items=data.results.slice(0,10).map((m:{id:number;title:string;overview:string;release_date:string})=>({...mockNews.find(x=>x.type==='Entertainment')!,id:`tmdb-${m.id}`,title:m.title,desc:m.overview||'Discover this title.',source:'TMDB',time:m.release_date||'Trending',url:`https://www.themoviedb.org/movie/${m.id}`})); return NextResponse.json({items,source:'tmdb'}); } catch { return NextResponse.json({items:mockNews.filter(x=>x.type==='Entertainment'),source:'mock',notice:'Recommendations unavailable; showing sample titles.'}); }
}
