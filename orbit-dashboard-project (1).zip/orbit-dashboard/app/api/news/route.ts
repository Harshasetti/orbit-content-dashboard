import { NextResponse } from 'next/server';
import { mockNews } from '@/lib/mock-data';
export async function GET() {
 const key=process.env.NEWS_API_KEY;
 if(!key) return NextResponse.json({items:mockNews,source:'mock',notice:'Set NEWS_API_KEY to enable live headlines.'});
 try { const res=await fetch(`https://newsapi.org/v2/top-headlines?language=en&pageSize=10&apiKey=${key}`,{next:{revalidate:900}}); if(!res.ok) throw new Error('News provider request failed'); const data=await res.json(); const items=data.articles.map((a:{title:string;description:string|null;source:{name:string};publishedAt:string;url:string},i:number)=>({...mockNews[i%mockNews.length],id:`news-${i}`,title:a.title||'Untitled story',desc:a.description||'Open the story to learn more.',source:a.source?.name||'News',time:a.publishedAt?new Date(a.publishedAt).toLocaleDateString():'Recently',url:a.url})); return NextResponse.json({items,source:'newsapi'}); } catch { return NextResponse.json({items:mockNews,source:'mock',notice:'Live news unavailable; showing sample stories.'}); }
}
