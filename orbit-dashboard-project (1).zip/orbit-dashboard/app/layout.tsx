import type { Metadata } from 'next';
import StoreProvider from '@/store/Provider';
import './globals.css';
export const metadata: Metadata = { title:'Orbit — Personalized Content Dashboard', description:'A personalized content dashboard for stories, recommendations, and community.' };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body><StoreProvider>{children}</StoreProvider></body></html>; }
