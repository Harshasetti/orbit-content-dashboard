# Submission checklist
- [ ] `npm install` succeeds
- [ ] `npm run dev` loads dashboard
- [ ] `npm run typecheck` passes
- [ ] `npm test` passes
- [ ] Playwright browser installed and `npm run test:e2e` passes
- [ ] Add valid server-side provider API keys (optional)
- [ ] Review API provider terms, quotas, and response fields
- [ ] Deploy and add the real live URL to README
- [ ] Add repository URL and screenshots to assignment submission
