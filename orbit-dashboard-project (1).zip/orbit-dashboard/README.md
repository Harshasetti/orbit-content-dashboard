# Orbit — Personalized Content Dashboard

A responsive content dashboard built with **Next.js App Router, TypeScript, React, and Redux Toolkit**. It includes a personalized feed, category filtering, debounced-by-render search, favorites, preferences, dark mode, trending view, pagination, mock community posts, and server-side API routes with graceful sample-data fallbacks.

## Requirements
- Node.js 20.9+ recommended
- npm

## Run locally
```bash
npm install
cp .env.example .env.local
npm run dev
```
Open http://localhost:3000.

## API routes
- `GET /api/news`: uses NewsAPI when `NEWS_API_KEY` is configured; otherwise returns sample stories.
- `GET /api/recommendations`: uses TMDB trending movies when `TMDB_API_KEY` is configured; otherwise returns sample recommendations.
- `GET /api/social`: returns a local mock community feed.

API keys are read only in server route handlers and should never be prefixed with `NEXT_PUBLIC_`. Add real keys to `.env.local` locally or your deployment provider's server environment settings. Provider responses can vary by plan, region, or account.

## Tests
```bash
npm test       # Redux unit tests
npm run typecheck
npx playwright install chromium
npm run test:e2e
```

## Suggested GitHub submission steps
1. Create a repository and commit the project source (never commit `.env.local`).
2. Push to GitHub.
3. Import the repository into Vercel or another Next.js host.
4. Add `NEWS_API_KEY` and `TMDB_API_KEY` as server-side environment variables if you want live provider data.
5. Run tests and include the actual results in your submission; tests have not been executed as part of this generated scaffold.

## Notes and limitations
- The social feed is intentionally mocked; there is no social network integration or authentication.
- Preferences, favorites, and theme currently live in Redux memory and reset on a full reload. Persistence can be added with Redux Persist or a small local-storage hydration layer.
- Drag-and-drop reordering was present in the HTML prototype but is not included in this Next.js implementation yet.
- Styling is hand-written CSS rather than Tailwind utilities; Tailwind can be introduced if required by the rubric.
- API routes use safe fallbacks, but production deployments should add provider-specific validation, rate limiting, logging, and error monitoring.
