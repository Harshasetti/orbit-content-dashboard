import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import type { ContentCategory } from '@/lib/types';
type State = { favorites: string[]; preferences: ContentCategory[]; darkMode: boolean; query: string; category: 'All' | ContentCategory; view: 'Feed' | 'Trending' | 'Favorites' };
const initialState: State = { favorites: [], preferences: ['Technology','Culture','Finance','Entertainment'], darkMode: false, query: '', category: 'All', view: 'Feed' };
const slice = createSlice({name:'content',initialState,reducers:{toggleFavorite(s,a:PayloadAction<string>){s.favorites=s.favorites.includes(a.payload)?s.favorites.filter(x=>x!==a.payload):[...s.favorites,a.payload]},setPreferences(s,a:PayloadAction<ContentCategory[]>){s.preferences=a.payload},toggleDarkMode(s){s.darkMode=!s.darkMode},setDarkMode(s,a:PayloadAction<boolean>){s.darkMode=a.payload},setQuery(s,a:PayloadAction<string>){s.query=a.payload},setCategory(s,a:PayloadAction<State['category']>){s.category=a.payload},setView(s,a:PayloadAction<State['view']>){s.view=a.payload}}});
export const {toggleFavorite,setPreferences,toggleDarkMode,setDarkMode,setQuery,setCategory,setView}=slice.actions;
export default slice.reducer;
