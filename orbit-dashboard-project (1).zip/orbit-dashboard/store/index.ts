import { configureStore } from '@reduxjs/toolkit';
import contentReducer from './contentSlice';
export const makeStore = () => configureStore({reducer:{content:contentReducer}});
export type AppStore = ReturnType<typeof makeStore>;
export type RootState = ReturnType<AppStore['getState']>;
export type AppDispatch = AppStore['dispatch'];
